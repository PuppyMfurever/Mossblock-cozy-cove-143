# Packaged app dependencies

The starter installs these packages from the files in this directory through `file:` dependencies in its `package.json`. Keep this directory with the starter and run `pnpm install --frozen-lockfile`. Don't run `pnpm add` for these packages, and don't install them from a registry.

- `@square/service-apps-apollo-client`

`provenance.json` records each package's version and SHA-256 digest. The starter's other dependencies install from public npm.
