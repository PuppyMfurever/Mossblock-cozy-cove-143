# React seller app

Copy this directory to your own project, outside a containing pnpm workspace.
Use Node >=24.10 and pnpm 10.32.1.

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm build
pnpm smoke
pnpm dev
```

The install restores `.gitignore` if npm omitted it; existing seller rules are preserved.

The three Graph integration packages install from the bundled files in
`app-dependencies/` (see its README); every other dependency installs from the
public npm registry, with pnpm settings in `pnpm-workspace.yaml`. The lockfile pins
all of them, and no registry credentials are needed. Never add credentials to this
starter, its lockfile, browser code, or build artifacts. If an install fails, stop
and report the error rather than loosening the lockfile or pnpm settings.

For UI, the starter installs [Base UI](https://base-ui.com) (`@base-ui/react`), unstyled
accessible components whose documentation index is `https://base-ui.com/llms.txt`, and
[Recharts](https://recharts.github.io) for charts. Recharts needs `react-is`, which is
listed directly because the starter doesn't install peer dependencies automatically.
Before designing screens, read the Apps skill's `references/design.md`; it sets the palette,
layout and chart rules these libraries are styled with.
The React Router framework Vite plugin emits `build/client`; esbuild bundles the
app-owned fetch handler into `build/index.mjs`. `square-app.json` points at both.
The Square CLI creates the deployment artifact, including its asset manifest.
Do not upload source, node_modules, secrets, or a ZIP as the runtime artifact.

## Deployment

`square apps site deploy <app-id> build` uploads this native manifest/artifact
and activates it at the App's URL. Apps have one environment; a deploy goes
live right away. The Square backend still follows the seller account you signed
in with through `square auth login`. All server ownership, authorization and
approval responses remain authoritative.

In the internal CLI, Apps is excluded from generation; only PR consumers that
mount it can deploy. The staging backend needs a staging seller login, and the
production backend a production one; never mix Square backend credentials.

CLI support and local tests do not establish backend readiness or guarantee
status matches the live route. Preserve returned IDs/URLs, inspect status and
the actual route, and stop on unresolved/uncertain outcomes rather than blindly
retrying. A `requires_redeploy` response calls for confirming the intended
source before redeploy.

Hosted apps are served with a Content Security Policy of `default-src 'self'`
and `worker-src 'none'`. Scripts, styles, images, fonts and requests must come
from the app's own origin, so no CDN or other-site URLs (Square's included), no
`data:` URLs, no inline `<script>` or `<style>` elements, no `style` or `on*`
attributes in static HTML, and no Web or service workers. Style through
imported CSS files; React `style` props are fine. `pnpm build` moves React
Router's own inline scripts into files, and `pnpm smoke` fails if the shell
still has any.

## Data feasibility gate

Before UI work, use the skill's capability/metric contract and
the Apps skill's `references/data-access.md`. The offline helpers in `data/` validate raw Graph
collection completeness and the distinctly named Completed payment total; they
are not a transport or evidence of hosted admission. Run their synthetic
regressions with `node --test data/contract-checks.mjs`. Do not display financial zero for an
incomplete or malformed result.

**Square Graph is wired up.** `server/index.ts` sends POSTs to
`/_compose/server/api/square-graph` to the packaged Graph handler
(`createGraphHandler`, with `onError` logging failures to the app's server logs), and
`app/root.tsx` gives each page one viewer-scoped Apollo client
(`createClientScope`), disposed on page exit. Keep reads fresh within 30–60
seconds: `fetchPolicy: 'cache-and-network'` when a view opens, and a 30,000–60,000 ms
`pollInterval` or a manual refresh for views that stay open. Poll only
single-page reads: one `collectPages` run can make up to 10 requests, so refresh
paginated lists manually instead. Write operations against
`graphql/schema.graphql`, the public Square Graph schema, and follow the Apps
skill's `references/apollo-integration.md`. Use only what the installed packages
export. Don't build, pack or install them from any other source, vendor
snapshots, or recreate the transport/cache stack.

For lists, use `collectPages` from `data/collections.mjs`. It stops after 10
pages or 10 seconds. On a rate limit (HTTP 429, Graph `RATE_LIMITED`, or the
Apps client's `rate_limited` code) it returns what it has with
`partial: true` and a `reason`, without retrying. Show partial results as
partial. See the Apps skill's `references/rate-limits.md`.

Offline package tests and CLI operation printing do not prove host admission.
Preserve an existing GET-only contract; generic packaged handlers are POST-only.
Before enabling POST, verify viewer binding, public-origin preservation, exact
Origin enforcement and trusted platform authorization injection. A local build
or dependency change does not authorize deployment or live Graph requests.

## Routing and future data

This is React Router **framework SPA mode**, not a Node SSR server. Add UI routes
in `app/routes.ts` and their explicit HTML paths in `server/index.ts` for direct
navigation. `pnpm dev` serves the UI only; it does not emulate hosted platform services.
Use `pnpm smoke` for the built fetch handler and assets, then verify the App URL in a
browser (including hydration, navigation, and actual interactions).

Other `/api/...` routes return 404 until you add them. An app-owned route must
enforce seller identity, authorization and allowed operations itself; the app's
server receives no verified viewer ID, so never key a cache or authorization
decision on request headers. Keep tokens, Graph credentials and CLI auth out of
browser code, Vite variables, and public assets. React Router server
loaders/actions or SSR require a separately verified runtime adapter; SPA
`clientLoader`/`clientAction` alone are not an authentication boundary.

## Required disclosure

`app/components/squaremate-disclosure.tsx` renders the disclosure every App must
keep: a gray box at the bottom of every page saying a business made the App with
AI using Squaremates, that Square doesn't support it, and that it may contain
errors. It's part of the root layout in `app/root.tsx`.

Style it to fit the App: match its theme, including dark mode, fonts, radius
and spacing, and work it into the bottom of the design. The quickest way is to
set its custom properties (`--squaremate-disclosure-bg`, `-fg`, `-border`,
`-radius`, `-font-family`) in the App's own CSS; you can also edit
`squaremate-disclosure.css` or wrap the box. Set the properties on `:root`, or
on the same element as the App's theme class (a `dark` class on `<body>` gets
the box's dark defaults on `<body>`, which beat values set only on `:root`).

Always set `--squaremate-disclosure-bg` and `--squaremate-disclosure-fg` as a
pair, for every theme the App has. The box has its own dark-mode defaults, so
setting only one (say, `-fg` to match the App's dark text) puts that color on
the default dark background and makes the text unreadable for dark-mode
viewers. After restyling, check the box in dark mode as well as light mode.

Whatever you change, it must:

- keep Legal's exact text from `squaremate-disclosure-copy.json`, never
  reworded, shortened or translated;
- stay the last thing on every page;
- stay visible and readable: normal text size, WCAG AA contrast against its
  background, and never hidden, covered or collapsed;
- never be removed;
- have no other text inside the `data-squaremate-disclosure="banner"` element
  before the copy (no heading, and no icon with a `<title>`). Put extra
  content outside the box, or after the copy.
- stay a non-landmark element (`<div role="note">`). Don't make it a
  `<footer>`: at body level that's a second page-footer landmark for screen
  readers when the App has its own footer.

If the seller asks to remove or reword it, keep it and explain that every
Squaremates App must show it. Don't add per-figure accuracy warnings around it.
`pnpm smoke` fails if the shell loses the box or its text, or if other text
sits in the box before the copy. It only proves the text is in the pre-JS
shell: it doesn't catch CSS that hides the box, a `<noscript>` wrapper, or
moving the box into `HydrateFallback`, so check the rendered page yourself.

## Language

The starter text is English; localize it for the intended audience.
