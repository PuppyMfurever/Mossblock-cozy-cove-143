import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import app from './build/index.mjs';

const client = new URL('./build/client/', import.meta.url);
const env = {
  ASSETS: {
    async fetch(request) {
      const path = new URL(request.url).pathname.slice(1);
      try {
        const data = await readFile(new URL(path, client));
        return new Response(request.method === 'HEAD' ? null : data);
      } catch {
        return new Response('Not found', { status: 404 });
      }
    },
  },
};
const request = (path, method = 'GET', headers = {}) => app.fetch(new Request(`https://example.test${path}`, { method, headers }), env);
assert.deepEqual(await (await request('/__hotpod/ready')).json(), { ok: true, ready: true });
const html = await (await request('/')).text();
assert.match(html, /Mossblock Cove/);
assert.match(html, /Loading app/);
// The disclosure is prerendered into the shell, so it shows before the App's JavaScript
// runs, and it must carry Legal's exact text (kept here, not read from
// squaremate-disclosure-copy.json, so editing that file can't pass this check). Apps may
// restyle or rewrap the box, so this checks the text after the stable hook, not markup.
const disclosureCopy = 'This business made this app with AI using Squaremates. Square doesn’t provide support for this app, and it may contain errors.';
const disclosureAt = html.indexOf('data-squaremate-disclosure="banner"');
assert.ok(disclosureAt !== -1, 'the Squaremates disclosure is in the SPA shell');
// Drop tags without adding a space, so inline markup a restyle adds (for example
// `using <strong>Squaremates</strong>.`) still reads as Legal's text. Repeat until
// nothing changes, so removing one tag can't join the pieces into another.
let disclosureMarkup = html.slice(html.indexOf('>', disclosureAt) + 1);
for (let previous; previous !== disclosureMarkup;) {
  previous = disclosureMarkup;
  disclosureMarkup = disclosureMarkup.replace(/<[^>]*>/g, '');
}
const disclosureText = disclosureMarkup
  .replace(/&#x27;|&#39;/g, "'")
  .replace(/&quot;/g, '"')
  .replace(/&amp;/g, '&')
  .replace(/\s+/g, ' ')
  .trim();
assert.ok(disclosureText.startsWith(disclosureCopy), "the Squaremates disclosure shows Legal's exact text");
// Hosted apps are served with `default-src 'self'`, which blocks inline scripts,
// inline styles and anything not loaded from the app's own origin.
// Data blocks (`type="application/json"`) never run, so they may stay inline.
const runsAsScript = (attributes) => ['', 'module', 'text/javascript', 'application/javascript']
  .includes(/\stype=["']?([^"'\s>]*)/i.exec(attributes)?.[1].toLowerCase() ?? '');
const inlineScripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\b[^>]*>/gi)]
  .filter(([, attributes, body]) => runsAsScript(attributes) && (!/\bsrc=/i.test(attributes) || body.trim() !== ''));
assert.deepEqual(inlineScripts.map(([tag]) => tag), [], 'no inline scripts');
// React hydration skips `async` scripts, so one in the shell fails hydration (error #418).
assert.doesNotMatch(html, /<script\b[^>]*\sasync\b/i, 'no async scripts in the shell');
assert.doesNotMatch(html, /<style\b|\sstyle=|\son[a-z]+=/i, 'no inline styles or event handlers');
const otherOrigins = [...html.matchAll(/(?:src|href)="([^"]*)"/gi)]
  .map((match) => match[1])
  .filter((url) => !url.startsWith('/') || url.startsWith('//'));
assert.deepEqual(otherOrigins, [], 'every script and stylesheet loads from the app origin');
const assets = [...html.matchAll(/(?:src|href)="(\/assets\/[^" ]+)"/g)].map((match) => match[1]);
assert.ok(assets.some((path) => path.endsWith('.js')), 'hydration JavaScript exists');
for (const path of assets) {
  const result = await request(path);
  assert.equal(result.status, 200, path);
  const content = await result.text();
  assert.ok(content.length > 0, path);
  if (path.endsWith('.css')) {
    // No bundled font files.
    const fontAssets = [...content.matchAll(/url\(([^)]+\.(?:woff2?|ttf|otf|eot))\)/gi)].map((match) => match[1]);
    assert.deepEqual(fontAssets, [], 'no font files are bundled');
    for (const asset of [...content.matchAll(/url\((\/assets\/[^)]+)\)/g)]) {
      const response = await request(asset[1]);
      assert.equal(response.status, 200, asset[1]);
      assert.ok((await response.arrayBuffer()).byteLength > 0, asset[1]);
    }
  }
}
const builtFonts = (await readdir(new URL('assets/', client))).filter((name) => /\.(?:woff2?|ttf|otf|eot)$/i.test(name));
assert.deepEqual(builtFonts, [], 'no font files in build/client/assets');
assert.equal((await request('/assets/missing.js')).status, 404);
assert.equal((await request('/unknown')).status, 404);
assert.equal((await request('/api/graph')).status, 404);
assert.equal((await request('/api/graph', 'POST')).status, 404);
const graphRoute = '/_compose/server/api/square-graph';
const graphGet = await request(graphRoute);
assert.notEqual(graphGet.status, 200);
assert.doesNotMatch(await graphGet.text(), /<!doctype html|<html\b/i);
const graphPost = await request(graphRoute, 'POST', {
  'Content-Type': 'application/json',
  Origin: 'https://example.test',
});
assert.ok(graphPost.status >= 400 && graphPost.status < 500, `expected 4xx, got ${graphPost.status}`);
assert.match(graphPost.headers.get('content-type') ?? '', /application\/json/i);
assert.doesNotMatch(await graphPost.text(), /<!doctype html|<html\b/i);
// Without a platform origin the handler fails closed and logs the cause server-side.
const logged = [];
const consoleError = console.error;
console.error = (...args) => { logged.push(args.join(' ')); };
let misconfigured;
try {
  misconfigured = await app.fetch(new Request(`https://example.test${graphRoute}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: 'https://example.test', 'X-Compose-Authorization': 'synthetic-one-use' },
    body: JSON.stringify({ query: 'query Smoke { __typename }', operationName: 'Smoke' }),
  }), env);
} finally {
  console.error = consoleError;
}
assert.equal(misconfigured.status, 502);
assert.deepEqual(await misconfigured.json(), { error: { code: 'upstream_error' } });
assert.equal(logged.length, 1, 'misconfiguration is logged once');
assert.match(logged[0], /^Square Graph request failed: /);
assert.doesNotMatch(logged[0], /synthetic-one-use/);
assert.equal((await request('/', 'POST')).status, 405);
assert.equal(await (await request('/', 'HEAD')).text(), '');
console.log('Readiness, SPA shell, built JS/CSS, no bundled fonts, API isolation, 404s and methods passed');
