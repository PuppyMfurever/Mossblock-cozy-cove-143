import { createGraphHandler, type GraphEnvironment } from '@square/service-apps-apollo-client/server';

type AppEnvironment = GraphEnvironment & {
  ASSETS: { fetch(request: Request): Promise<Response> };
};

const GRAPH_ROUTE = '/_compose/server/api/square-graph';

// The browser only sees a sanitized 502, so log the cause (for example a missing
// platform origin binding) to the app's server logs. Name and message only:
// never log request bodies, headers, or the Graph binding.
const handleGraphRequest = createGraphHandler(undefined, {
  route: GRAPH_ROUTE,
  onError: (error) => {
    console.error('Square Graph request failed:', error instanceof Error ? `${error.name}: ${error.message}` : 'unknown error');
  },
});

export default {
  async fetch(request: Request, env: AppEnvironment): Promise<Response> {
    const url = new URL(request.url);
    // Readiness endpoint the apps runtime polls before routing traffic to a deployment.
    if (url.pathname === '/__hotpod/ready') {
      return Response.json({ ok: true, ready: true });
    }
    // The platform must authenticate the viewer and inject trusted Graph binding before dispatch.
    if (url.pathname === GRAPH_ROUTE) {
      return handleGraphRequest(request, env);
    }
    // Reserve app-owned API routes: never turn an API failure into the SPA shell.
    if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
      return Response.json({ error: 'Not found' }, { status: 404 });
    }
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return new Response('Method not allowed', { status: 405, headers: { Allow: 'GET, HEAD' } });
    }
    // Add explicitly supported client routes here; do not mask missing assets as HTML.
    if (url.pathname === '/') {
      url.pathname = '/index.html';
      return env.ASSETS.fetch(new Request(url, request));
    }
    return env.ASSETS.fetch(request);
  },
};
