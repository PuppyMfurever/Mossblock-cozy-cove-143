import { reactRouter } from '@react-router/dev/vite';
import { defineConfig } from 'vite';

// Emit every imported asset as a file: hosted apps' CSP blocks the `data:` URLs
// Vite would otherwise inline small images and fonts as.
export default defineConfig({ build: { assetsInlineLimit: 0 }, plugins: [reactRouter()] });
