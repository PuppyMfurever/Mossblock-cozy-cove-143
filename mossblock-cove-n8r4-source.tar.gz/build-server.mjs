import { build } from 'esbuild';

await build({
  entryPoints: ['server/index.ts'],
  outfile: 'build/index.mjs',
  bundle: true,
  format: 'esm',
  platform: 'neutral',
  target: 'es2022',
});
