import assert from 'node:assert/strict';
import test from 'node:test';

import {
  collectPages, completedPaymentTotal, connectionPage, ordersPage,
} from './collections.mjs';

const scope = {
  merchantId: 'merchant-1',
  locationIds: ['location-1'],
  currency: 'USD',
  start: '2026-03-08T08:00:00Z',
  end: '2026-03-09T07:00:00Z',
  cutoff: '2026-03-09T07:00:00Z',
};
const payment = (overrides = {}) => ({
  id: 'payment-1',
  locationId: 'location-1',
  status: 'COMPLETED',
  createdAt: scope.start,
  totalMoney: { amount: 1234, currency: 'USD' },
  ...overrides,
});
const orders = (items, cursor = null) => ({ data: { searchOrders: { orders: items, cursor } } });
const payments = (nodes, hasNextPage = false, endCursor = null) => ({
  data: { payments: { nodes, pageInfo: { hasNextPage, endCursor } } },
});
const adaptPayments = (envelope) => connectionPage(envelope, 'payments', ['id', 'locationId', 'status', 'createdAt', 'totalMoney.amount', 'totalMoney.currency']);
const collect = (items, overrides = {}) => collectPages({
  scope, fetchPage: async () => payments(items), adaptPage: adaptPayments, ...overrides,
});

test('operation-specific raw envelopes accept populated and explicit terminal empty collections', () => {
  assert.deepEqual(ordersPage(orders([{ id: 'order-1' }], 'next')), { items: [{ id: 'order-1' }], cursor: 'next' });
  assert.deepEqual(ordersPage({ data: { searchOrders: { orders: null, orderEntries: null, cursor: null } } }), { items: [], cursor: null });
  for (const empty of [null, []]) {
    assert.deepEqual(ordersPage(orders(empty)), { items: [], cursor: null });
    assert.deepEqual(adaptPayments(payments(empty)), { items: [], cursor: null });
  }
  assert.equal(adaptPayments(payments([payment()], false, 'last-seen')).cursor, null);
});

test('orders reject missing requested roots, errors, null roots and nonterminal null', () => {
  const invalid = [null, {}, { data: null }, { data: {} }, { data: { searchOrders: null } },
    { objects: [], cursor: null }, { data: { searchOrders: { orders: [] } } },
    { data: { searchOrders: { cursor: null } } }, orders(null, 'next'), orders([], ' '),
    orders([null]), orders([{}]), orders([{ id: null }]),
    { ...orders([]), errors: [{ message: 'unauthorized' }] },
    { ...orders([]), errors: null },
    { data: { searchOrders: { orders: [], cursor: null, errors: [{ code: 'DENIED' }] } } },
    { data: { searchOrders: { orders: null, orderEntries: [{ orderId: 'order-1' }], cursor: null } } },
    { data: { searchOrders: { orders: null, orderEntries: [], cursor: null } } }];
  for (const envelope of invalid) { assert.throws(() => ordersPage(envelope)); }
  assert.throws(() => ordersPage(orders([{ id: '1' }]), ['totalMoney.amount']));
});

test('connections fail closed on malformed pagination, requested fields, null collections, and domain errors', () => {
  const invalid = [
    { data: null }, { data: { payments: null } },
    { data: { payments: { nodes: [] } } },
    { data: { payments: { nodes: [], pageInfo: null } } },
    { data: { payments: { nodes: [], pageInfo: { hasNextPage: false } } } },
    { data: { payments: { nodes: [], pageInfo: { endCursor: null } } } },
    payments(null, true, 'next'), payments([], true, null), payments([], 'false'),
    payments([], false, 3), payments([payment({ totalMoney: null })]),
    payments([payment({ totalMoney: { currency: 'USD' } })]),
    { ...payments(null), errors: [{ message: 'failed' }] },
    { data: { payments: { nodes: null, pageInfo: { hasNextPage: false, endCursor: null }, errors: ['failed'] } } },
  ];
  for (const envelope of invalid) { assert.throws(() => adaptPayments(envelope)); }
});

test('pagination preserves frozen scope and completes only on terminal evidence', async () => {
  const requests = [];
  const result = await collect([], {
    fetchPage: async (request) => {
      requests.push(request);
      assert.ok(Object.isFrozen(request.scope.locationIds));
      return requests.length === 1 ? payments([payment()], true, 'next') : payments([]);
    },
  });
  assert.equal(result.pageCount, 2);
  assert.equal(result.items.length, 1);
  assert.deepEqual(requests.map((request) => request.cursor), [null, 'next']);
  assert.equal(requests[0].scope, requests[1].scope);
  assert.throws(() => { result.items[0].totalMoney.amount = 0; });
  assert.equal(completedPaymentTotal(result, scope).amount, 1234);
});

test('an empty-string cursor ends pagination like null', async () => {
  // Staging Graph returns `cursor: ""` on the last page of some operations.
  for (const cursor of [null, '']) {
    assert.deepEqual(ordersPage(orders([{ id: 'order-1' }], cursor)), { items: [{ id: 'order-1' }], cursor: null });
    assert.deepEqual(ordersPage(orders(null, cursor)), { items: [], cursor: null });
    assert.deepEqual(adaptPayments(payments([payment()], false, cursor)), { items: [payment()], cursor: null });
    assert.throws(() => adaptPayments(payments([], true, cursor)), /Nonterminal null cursor/);
    const pages = [{ items: [{ id: 'item-1' }], cursor: 'next' }, { items: [{ id: 'item-2' }], cursor }];
    const result = await collectPages({ scope, fetchPage: async () => pages.shift(), adaptPage: (page) => page });
    assert.deepEqual({ complete: result.complete, pageCount: result.pageCount, items: result.items.map((item) => item.id) },
      { complete: true, pageCount: 2, items: ['item-1', 'item-2'] });
  }
});

test('budget exhaustion returns partial results instead of throwing; repeated cursors, malformed pages and fetch failures still throw', async () => {
  const atPageLimit = await collect([], { maxPages: 1, fetchPage: async () => payments([payment()], true, 'next') });
  assert.deepEqual({ complete: atPageLimit.complete, partial: atPageLimit.partial, reason: atPageLimit.reason }, { complete: false, partial: true, reason: 'page_limit' });
  assert.equal(atPageLimit.items.length, 1);
  await assert.rejects(collect([], { fetchPage: async () => payments([], true, 'same') }), /Repeated/);
  await assert.rejects(collect([], { fetchPage: async () => { throw new Error('HTTP 403'); } }), /403/);
  await assert.rejects(collect([], { adaptPage: () => ({ items: [] }) }), /Malformed/);
  for (const maxPages of [0, -1, 1.5, Infinity]) { await assert.rejects(collect([], { maxPages })); }
  let call = 0;
  await assert.rejects(collect([], { fetchPage: async () => (++call === 1 ? payments([payment()], true, 'next') : { data: null }) }));
});

test('default page budget stops at 10 pages with reason page_limit', async () => {
  let calls = 0;
  const result = await collect([], {
    fetchPage: async () => { calls += 1; return payments([payment()], true, `cursor-${calls}`); },
  });
  assert.equal(calls, 10);
  assert.equal(result.pageCount, 10);
  assert.equal(result.items.length, 10);
  assert.deepEqual({ complete: result.complete, partial: result.partial, reason: result.reason }, { complete: false, partial: true, reason: 'page_limit' });
});

test('time budget stops traversal with reason time_limit using an injected clock', async () => {
  let calls = 0;
  let clock = 0;
  const result = await collect([], {
    now: () => clock,
    fetchPage: async () => {
      calls += 1;
      clock += 6_000; // exceeds the 10s default budget on the second check
      return payments([payment()], true, `cursor-${calls}`);
    },
  });
  assert.equal(calls, 2);
  assert.equal(result.pageCount, 1);
  assert.deepEqual({ complete: result.complete, partial: result.partial, reason: result.reason }, { complete: false, partial: true, reason: 'time_limit' });
});

test('a page fetch that outlives the time budget is aborted and reported as time_limit', async () => {
  let signal;
  const result = await collect([], {
    budgetMs: 30,
    fetchPage: ({ signal: fetchSignal }) => {
      signal = fetchSignal;
      return new Promise(() => {});
    },
  });
  assert.equal(signal.aborted, true);
  assert.deepEqual({ complete: result.complete, reason: result.reason, pageCount: result.pageCount }, { complete: false, reason: 'time_limit', pageCount: 0 });
});

test('a terminal page that arrives after the deadline is not reported complete', async () => {
  let clock = 0;
  const result = await collect([], {
    now: () => clock,
    fetchPage: async () => {
      clock += 20_000;
      return payments([payment()], false, null);
    },
  });
  assert.deepEqual({ complete: result.complete, reason: result.reason }, { complete: false, reason: 'time_limit' });
});

test('a failure thrown after the deadline keeps its cause instead of reading as time_limit', async () => {
  const lateFailure = (error) => {
    let clock = 0;
    return collect([], {
      now: () => clock,
      fetchPage: async () => {
        clock += 20_000;
        throw error;
      },
    });
  };
  await assert.rejects(lateFailure(new Error('HTTP 403')), /403/);
  const limited = await lateFailure(Object.assign(new Error('Too many requests'), { status: 429 }));
  assert.equal(limited.reason, 'rate_limited');
});

test('a rate-limited fetch stops immediately without retrying and returns items gathered so far', async () => {
  let calls = 0;
  const result = await collect([], {
    fetchPage: async () => {
      calls += 1;
      if (calls === 2) { return { kind: 'backend', code: 'rate_limited' }; }
      return payments([payment()], true, `cursor-${calls}`);
    },
  });
  assert.equal(calls, 2);
  assert.equal(result.items.length, 1);
  assert.deepEqual({ complete: result.complete, partial: result.partial, reason: result.reason }, { complete: false, partial: true, reason: 'rate_limited' });

  let thrownCalls = 0;
  const thrownResult = await collect([], {
    fetchPage: async () => {
      thrownCalls += 1;
      if (thrownCalls === 2) {
        throw Object.assign(new Error('rate limited'), { code: 'rate_limited' });
      }
      return payments([payment()], true, `cursor-${thrownCalls}`);
    },
  });
  assert.equal(thrownCalls, 2);
  assert.equal(thrownResult.reason, 'rate_limited');
});

test('Graph RATE_LIMITED errors and HTTP 429 also stop traversal as rate_limited', async () => {
  const limited = [
    { errors: [{ message: 'Too many requests', extensions: { code: 'RATE_LIMITED' } }] },
    { kind: 'graphql', status: 429 },
    // Apollo errorPolicy 'all': partial data plus a CombinedGraphQLErrors-shaped error.
    { data: { payments: null }, error: { errors: [{ message: 'Too many requests', extensions: { code: 'RATE_LIMITED' } }] } },
  ];
  for (const outcome of limited) {
    let calls = 0;
    const result = await collect([], {
      fetchPage: async () => {
        calls += 1;
        if (calls === 2) { return outcome; }
        return payments([payment()], true, `cursor-${calls}`);
      },
    });
    assert.equal(calls, 2);
    assert.deepEqual({ items: result.items.length, partial: result.partial, reason: result.reason }, { items: 1, partial: true, reason: 'rate_limited' });
  }
  const thrown = await collect([], {
    fetchPage: async () => { throw Object.assign(new Error('Too many requests'), { status: 429 }); },
  });
  assert.equal(thrown.reason, 'rate_limited');
});

test('a non-rate-limit Apollo errorPolicy all error never certifies a page, even a terminal null one', async () => {
  // errorPolicy 'all' resolves { data, error }; a failed field reads as a terminal null collection.
  const failed = { ...payments(null), error: { errors: [{ message: 'Square could not resolve the requested field', path: ['payments', 'nodes'] }] } };
  assert.throws(() => adaptPayments(failed), /Response error/);
  await assert.rejects(collect([], { fetchPage: async () => failed }));
  // A later failed page must not turn earlier pages into a complete, understated collection.
  await assert.rejects(collect([], {
    fetchPage: async ({ cursor }) => (cursor === null ? payments([payment()], true, 'cursor-1') : failed),
  }));
});

test('full completion returns complete:true, partial:false', async () => {
  const result = await collect([payment()]);
  assert.deepEqual({ complete: result.complete, partial: result.partial }, { complete: true, partial: false });
});

test('a garbage envelope or a missing pageInfo never completes a collection, even with zero items', async () => {
  await assert.rejects(collect([], { fetchPage: async () => ({}) }));
  await assert.rejects(collect([], { fetchPage: async () => ({ data: { payments: { nodes: [] } } }) }));
  await assert.rejects(collect([], { fetchPage: async () => payments(null, true, 'next') }));
});

test('totals reject a collection whose provenance differs from the expected scope', async () => {
  const collected = await collect([payment()], { scope: { ...scope, settingsVersion: 'v1', timezone: 'America/Los_Angeles' } });
  assert.throws(() => completedPaymentTotal(collected, { ...scope, settingsVersion: 'v2', timezone: 'America/Los_Angeles' }), /Scope mismatch: settingsVersion/);
  assert.throws(() => completedPaymentTotal(collected, { ...scope, settingsVersion: 'v1' }), /Scope mismatch: timezone/);
  assert.equal(completedPaymentTotal(collected, { ...scope, settingsVersion: 'v1', timezone: 'America/Los_Angeles' }).count, 1);
});

test('total includes already-processed tips/tax once, ignores refunds/fees and supports methods/locations', async () => {
  const both = { ...scope, locationIds: ['location-1', 'location-2'] };
  const second = { ...scope, locationIds: ['location-2'] };
  const result = completedPaymentTotal([
    await collect([payment({
      sourceType: 'CARD', tipMoney: { amount: 100 }, refundedMoney: { amount: 20 }, feeMoney: { amount: 10 },
    })]),
    await collect([payment({
      id: 'cash', sourceType: 'CASH', locationId: 'location-2', totalMoney: { amount: 500, currency: 'USD' },
    })], { scope: second }),
  ], both);
  assert.equal(result.name, 'Completed payment total');
  assert.equal(result.amount, 1734);
  assert.equal(result.count, 2);
  assert.equal(completedPaymentTotal(await collect([]), scope).amount, 0);
  assert.throws(() => completedPaymentTotal({ complete: true, items: [], scope }, scope), /Unproven/);
});

test('non-COMPLETED payments are ordinary and are skipped from the total, not rejected', async () => {
  const result = completedPaymentTotal(await collect([
    payment({ id: 'pending', status: 'PENDING' }),
    payment({ id: 'failed', status: 'FAILED' }),
    payment({ id: 'canceled', status: 'CANCELED' }),
    payment({ id: 'approved', status: 'APPROVED' }),
    payment({ id: 'completed' }),
  ]), scope);
  assert.equal(result.amount, 1234);
  assert.equal(result.count, 1);
});

test('adversarial payment shape, status, scope, currency, dates and money fail closed', async () => {
  const invalid = [
    { id: '' }, { id: 42 }, { locationId: 'elsewhere' }, { locationId: null },
    { merchantId: 'elsewhere' }, { status: null }, { status: '' }, { status: 42 },
    { createdAt: scope.end }, { createdAt: '2026-03-08T07:59:59Z' },
    { createdAt: '2026-02-30T08:00:00Z' }, { createdAt: '2026-03-08' },
    { totalMoney: null }, { totalMoney: { amount: null, currency: 'USD' } },
    { totalMoney: { amount: -1, currency: 'USD' } }, { totalMoney: { amount: 1.2, currency: 'USD' } },
    { totalMoney: { amount: '1234', currency: 'USD' } },
    { totalMoney: { amount: Number.MAX_SAFE_INTEGER + 1, currency: 'USD' } },
    { totalMoney: { amount: NaN, currency: 'USD' } },
    { totalMoney: { amount: 1, currency: 'EUR' } },
  ];
  for (const overrides of invalid) {
    await assert.rejects(async () => completedPaymentTotal(await collect([payment(overrides)]), scope));
  }
});

test('identical duplicate payment observations count once; conflicting ones are rejected', async () => {
  const identical = await collect([payment(), payment()]);
  const result = completedPaymentTotal(identical, scope);
  assert.equal(result.amount, 1234);
  assert.equal(result.count, 1);
  const withArrays = await collect([payment({ refundIds: ['r1'] }), payment({ refundIds: ['r1'] })]);
  assert.equal(completedPaymentTotal(withArrays, scope).count, 1);
  const pages = [payments([payment()], true, 'page-2'), payments([payment()])];
  const acrossPages = await collect([], { fetchPage: async () => pages.shift() });
  assert.equal(completedPaymentTotal(acrossPages, scope).count, 1);
  for (const second of [payment({ totalMoney: { amount: 5, currency: 'USD' } }), payment({ status: 'PENDING' }), payment({ refundIds: ['r2'] })]) {
    const conflicting = await collect([payment(), second]);
    assert.throws(() => completedPaymentTotal(conflicting, scope), /Conflicting duplicate/);
  }
});

test('unsafe sums and changed scopes are rejected', async () => {
  const large = await collect([payment({ totalMoney: { amount: Number.MAX_SAFE_INTEGER, currency: 'USD' } }), payment({ id: 'second' })]);
  assert.throws(() => completedPaymentTotal(large, scope), /Unsafe sum/);
  const result = await collect([]);
  for (const override of [
    { merchantId: 'other' }, { locationIds: ['location-2'] }, { locationIds: ['location-1', 'location-2'] }, { currency: 'EUR' },
    { start: scope.end }, { end: scope.start }, { cutoff: scope.start },
    { start: '2026-02-30T08:00:00Z' }, { locationIds: [] },
    { locationIds: ['location-1', 'location-1'] }, { currency: 'usd' },
    { cutoff: '2026-03-08T10:00:00Z' },
  ]) { assert.throws(() => completedPaymentTotal(result, { ...scope, ...override })); }
});

test('DST-derived 23-hour boundaries, millisecond instants and partial-day cutoff stay half-open', async () => {
  const partial = { ...scope, cutoff: '2026-03-08T12:00:00.000Z' };
  const result = await collect([payment({ createdAt: '2026-03-08T11:59:59.999Z' })], { scope: partial });
  assert.equal(completedPaymentTotal(result, partial).amount, 1234);
  const boundary = await collect([payment({ createdAt: partial.cutoff })], { scope: partial });
  assert.throws(() => completedPaymentTotal(boundary, partial), /half-open/);
  const jpy = { ...scope, currency: 'JPY' };
  const yen = await collect([payment({ totalMoney: { amount: 123, currency: 'JPY' } })], { scope: jpy });
  assert.equal(completedPaymentTotal(yen, jpy).amount, 123);
});

test('a multi-location total needs one complete collection per location', async () => {
  const both = { ...scope, locationIds: ['location-1', 'location-2'] };
  const first = await collect([]);
  const second = await collect([], { scope: { ...scope, locationIds: ['location-2'] } });
  assert.throws(() => completedPaymentTotal(first, both), /Location scope mismatch/);
  assert.throws(() => completedPaymentTotal([first, first], both), /Location scope mismatch/);
  const combined = await collect([], { scope: both });
  assert.throws(() => completedPaymentTotal(combined, both), /exactly one location/);
  assert.throws(() => completedPaymentTotal([], both), /Unproven/);
  const misplaced = await collect([payment({ locationId: 'location-2' })]);
  assert.throws(() => completedPaymentTotal(misplaced, scope), /Payment location mismatch/);
  assert.equal(completedPaymentTotal([first, second], both).amount, 0);
});
