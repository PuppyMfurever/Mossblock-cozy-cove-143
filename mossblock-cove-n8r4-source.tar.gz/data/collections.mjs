// Offline contracts only: these adapters do not provide or admit a hosted transport.
const completedCollections = new WeakSet();
const own = (value, key) => Object.hasOwn(value, key);
const record = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
function requireCondition(condition, message) {
  if (!condition) { throw new Error(message); }
}
function errorFree(value) {
  if (own(value, 'errors')) {
    requireCondition(Array.isArray(value.errors) && value.errors.length === 0, 'Response errors');
  }
}
// Apollo errorPolicy 'all' resolves { data, error }: any error left beside data is a failure.
function noApolloError(value) {
  requireCondition(!own(value, 'error') || value.error === null || value.error === undefined, 'Response error');
}
function rootOf(envelope, operation) {
  requireCondition(record(envelope), 'Missing Graph envelope');
  errorFree(envelope);
  noApolloError(envelope);
  requireCondition(record(envelope.data) && own(envelope.data, operation), 'Missing requested root');
  const root = envelope.data[operation];
  requireCondition(record(root), 'Null or malformed root');
  errorFree(root);
  return root;
}
// Graph ends some operations (catalog search included) with `cursor: ""` rather than null.
function cursorOf(cursor) {
  if (cursor === '') { return null; }
  requireCondition(cursor === null || (typeof cursor === 'string' && cursor.trim().length > 0), 'Invalid cursor');
  return cursor;
}
function itemsOf(items, cursor, requiredFields) {
  requireCondition(Array.isArray(requiredFields) && requiredFields.every((field) => typeof field === 'string' && field.length > 0), 'Invalid requested fields');
  // Documented terminal case only (see references/data-access.md); any other null fails closed.
  if (items === null) {
    requireCondition(cursor === null, 'Nonterminal null collection');
    return [];
  }
  requireCondition(Array.isArray(items), 'Missing or malformed collection');
  for (const item of items) {
    requireCondition(record(item), 'Malformed item');
    errorFree(item);
    for (const field of requiredFields) {
      let value = item;
      for (const key of field.split('.')) {
        requireCondition(record(value) && own(value, key), `Missing requested field: ${field}`);
        value = value[key];
      }
      requireCondition(value !== null && value !== undefined, `Null requested field: ${field}`);
    }
  }
  return items;
}

/** Raw searchOrders Graph envelope with full orders (not `returnEntries`); not CLI-normalized. */
export function ordersPage(envelope, requiredFields = ['id']) {
  const root = rootOf(envelope, 'searchOrders');
  requireCondition(own(root, 'orders') && own(root, 'cursor'), 'Missing orders/cursor');
  // Entry mode nulls `orders`, which would otherwise read as a terminal empty page.
  requireCondition(!own(root, 'orderEntries') || root.orderEntries === null, 'Entry-mode searchOrders is unsupported');
  const cursor = cursorOf(root.cursor);
  return { items: itemsOf(root.orders, cursor, requiredFields), cursor };
}

/** Supply the exact verified operation root and every requested non-null item field. */
export function connectionPage(envelope, operation, requiredFields = ['id']) {
  requireCondition(typeof operation === 'string' && operation.length > 0, 'Missing operation');
  const root = rootOf(envelope, operation);
  requireCondition(own(root, 'nodes') && record(root.pageInfo), 'Missing nodes/pageInfo');
  const info = root.pageInfo;
  requireCondition(own(info, 'hasNextPage') && typeof info.hasNextPage === 'boolean' && own(info, 'endCursor'), 'Malformed pageInfo');
  errorFree(info);
  const endCursor = cursorOf(info.endCursor);
  requireCondition(!info.hasNextPage || endCursor !== null, 'Nonterminal null cursor');
  const cursor = info.hasNextPage ? endCursor : null;
  return { items: itemsOf(root.nodes, cursor, requiredFields), cursor };
}

function freeze(value) {
  if (value !== null && typeof value === 'object') {
    for (const child of Object.values(value)) { freeze(child); }
    Object.freeze(value);
  }
  return value;
}

// HTTP 429, Square Graph's `RATE_LIMITED` error code, or the Apps client's `rate_limited` backend code.
// Also checks one level of `error`: Apollo's errorPolicy 'all' resolves with { data, error }.
const RATE_LIMIT_CODES = new Set(['RATE_LIMITED', 'rate_limited']);
function rateLimited(outcome, nested = false) {
  if (!record(outcome)) { return false; }
  if (outcome.status === 429 || RATE_LIMIT_CODES.has(outcome.code)) { return true; }
  if (Array.isArray(outcome.errors)
    && outcome.errors.some((error) => record(error) && record(error.extensions) && RATE_LIMIT_CODES.has(error.extensions.code))) {
    return true;
  }
  return !nested && rateLimited(outcome.error, true);
}

/** Never throws on budget/rate-limit exhaustion; those return partial results instead.
 * fetchPage must reject transport/HTTP failures (those still throw), but may also
 * throw or return a rate-limited Outcome, which stops traversal without retrying.
 * Scope is immutable and identical on every request; adapters validate raw envelopes.
 * Terminal traversal is evidence of pagination only, not server snapshot consistency.
 * Malformed envelopes, repeated cursors and non-rate-limit errors (including an
 * Apollo errorPolicy 'all' `error` beside data) are failures, not partial data: still throw.
 */
const TIMED_OUT = Symbol('timed out');

export async function collectPages({
  fetchPage, adaptPage, scope, maxPages = 10, budgetMs = 10_000, now = Date.now,
}) {
  requireCondition(Number.isSafeInteger(maxPages) && maxPages > 0, 'Invalid page budget');
  requireCondition(Number.isFinite(budgetMs) && budgetMs > 0, 'Invalid time budget');
  requireCondition(record(scope), 'Missing scope');
  const fixedScope = freeze(structuredClone(scope));
  const items = [];
  const seen = new Set();
  let cursor = null;
  const deadline = now() + budgetMs;
  for (let pageCount = 1; pageCount <= maxPages; pageCount += 1) {
    if (now() >= deadline) {
      return freeze(structuredClone({
        complete: false, partial: true, reason: 'time_limit', items, scope: fixedScope, pageCount: pageCount - 1,
      }));
    }
    let fetched;
    const controller = new AbortController();
    let timer;
    const expired = new Promise((resolve) => {
      timer = setTimeout(() => {
        controller.abort();
        resolve(TIMED_OUT);
      }, Math.max(0, deadline - now()));
    });
    try {
      fetched = await Promise.race([fetchPage({ cursor, scope: fixedScope, signal: controller.signal }), expired]);
    } catch (error) {
      // Only our own abort is a timeout; a late failure keeps its real cause.
      if (controller.signal.aborted) {
        fetched = TIMED_OUT;
      } else if (rateLimited(error)) {
        return freeze(structuredClone({
          complete: false, partial: true, reason: 'rate_limited', items, scope: fixedScope, pageCount: pageCount - 1,
        }));
      } else {
        throw error;
      }
    } finally {
      clearTimeout(timer);
    }
    if (fetched === TIMED_OUT || now() >= deadline) {
      return freeze(structuredClone({
        complete: false, partial: true, reason: 'time_limit', items, scope: fixedScope, pageCount: pageCount - 1,
      }));
    }
    if (rateLimited(fetched)) {
      return freeze(structuredClone({
        complete: false, partial: true, reason: 'rate_limited', items, scope: fixedScope, pageCount: pageCount - 1,
      }));
    }
    // Rate limits stop above; any other error must not reach a caller-supplied adapter,
    // where a failed terminal null collection would read as a complete empty page.
    if (record(fetched)) { noApolloError(fetched); }
    const page = adaptPage(fetched);
    requireCondition(record(page) && Array.isArray(page.items) && own(page, 'cursor'), 'Malformed adapted page');
    cursor = cursorOf(page.cursor);
    items.push(...page.items);
    if (cursor === null) {
      const result = freeze(structuredClone({
        complete: true, partial: false, items, scope: fixedScope, pageCount,
      }));
      completedCollections.add(result);
      return result;
    }
    requireCondition(!seen.has(cursor), 'Repeated cursor: incomplete');
    seen.add(cursor);
  }
  return freeze(structuredClone({
    complete: false, partial: true, reason: 'page_limit', items, scope: fixedScope, pageCount: maxPages,
  }));
}

function instant(value) {
  requireCondition(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(value), 'Expected canonical UTC timestamp');
  const time = Date.parse(value);
  const canonical = value.includes('.') ? value : value.replace('Z', '.000Z');
  requireCondition(Number.isFinite(time) && new Date(time).toISOString() === canonical, 'Invalid timestamp');
  return time;
}
function id(value) {
  return typeof value === 'string' && value.trim().length > 0;
}
function paymentScope(scope) {
  requireCondition(record(scope) && id(scope.merchantId), 'Invalid merchant scope');
  requireCondition(Array.isArray(scope.locationIds) && scope.locationIds.length > 0 && scope.locationIds.every(id) && new Set(scope.locationIds).size === scope.locationIds.length, 'Invalid location scope');
  requireCondition(typeof scope.currency === 'string' && /^[A-Z]{3}$/.test(scope.currency), 'Invalid currency');
  const start = instant(scope.start);
  const end = instant(scope.end);
  const cutoff = instant(scope.cutoff);
  requireCondition(start < end && cutoff > start, 'Invalid interval/cutoff');
  return { start, end: Math.min(end, cutoff) };
}

function sameValue(left, right) {
  if (Object.is(left, right)) { return true; }
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length
      && left.every((item, index) => sameValue(item, right[index]));
  }
  if (!record(left) || !record(right)) { return false; }
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) { return false; }
  return leftKeys.every((key) => own(right, key) && sameValue(left[key], right[key]));
}

/** Completed payment total in safe integer minor units, never net sales.
 * Requires complete, unmodified collections from collectPages, one per location
 * (payments filter one location per request), together covering the expected scope.
 * Merchant identity is trusted request provenance, not inferred from payment fields.
 * Other statuses are skipped, not rejected. Identical duplicate IDs count once;
 * conflicting duplicates throw.
 */
export function completedPaymentTotal(collections, expectedScope) {
  const list = Array.isArray(collections) ? collections : [collections];
  requireCondition(list.length > 0 && list.every((collection) => completedCollections.has(collection)), 'Unproven collection completeness');
  const interval = paymentScope(expectedScope);
  const locations = [];
  for (const collection of list) {
    paymentScope(collection.scope);
    requireCondition(collection.scope.locationIds.length === 1, 'Collection must cover exactly one location');
    // Every provenance field (timezone, source, settings version, ...) must match, not just the bounds.
    const keys = new Set([...Object.keys(collection.scope), ...Object.keys(expectedScope)]);
    for (const key of keys) {
      if (key === 'locationIds') { continue; }
      requireCondition(sameValue(collection.scope[key], expectedScope[key]), `Scope mismatch: ${key}`);
    }
    locations.push(collection.scope.locationIds[0]);
  }
  requireCondition(locations.length === expectedScope.locationIds.length && new Set(locations).size === locations.length && locations.every((location) => expectedScope.locationIds.includes(location)), 'Location scope mismatch');
  const seen = new Map();
  let amount = 0;
  let count = 0;
  for (const collection of list) {
    const [location] = collection.scope.locationIds;
    for (const payment of collection.items) {
      requireCondition(record(payment) && id(payment.id), 'Invalid payment ID');
      requireCondition(payment.locationId === location, 'Payment location mismatch');
      if (seen.has(payment.id)) {
        requireCondition(sameValue(seen.get(payment.id), payment), 'Conflicting duplicate payment ID');
        continue;
      }
      seen.set(payment.id, payment);
      if (own(payment, 'merchantId')) { requireCondition(payment.merchantId === expectedScope.merchantId, 'Payment merchant mismatch'); }
      requireCondition(typeof payment.status === 'string' && payment.status.length > 0, 'Invalid payment status');
      if (payment.status !== 'COMPLETED') { continue; }
      const created = instant(payment.createdAt);
      requireCondition(created >= interval.start && created < interval.end, 'Payment outside half-open interval/cutoff');
      requireCondition(record(payment.totalMoney) && payment.totalMoney.currency === expectedScope.currency, 'Missing money or currency mismatch');
      const value = payment.totalMoney.amount;
      requireCondition(Number.isSafeInteger(value) && value >= 0, 'Invalid minor-unit money');
      requireCondition(Number.isSafeInteger(amount + value), 'Unsafe sum');
      amount += value;
      count += 1;
    }
  }
  return Object.freeze({
    name: 'Completed payment total',
    amount,
    currency: expectedScope.currency,
    count,
    pageCount: list.reduce((sum, collection) => sum + collection.pageCount, 0),
    scope: freeze(structuredClone(expectedScope)),
    complete: true,
  });
}
