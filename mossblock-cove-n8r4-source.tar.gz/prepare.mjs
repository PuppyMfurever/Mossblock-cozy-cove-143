import { writeFileSync } from 'node:fs';

// npm omits .gitignore from the CLI tarball. Restore it during the ordinary
// starter install, without replacing any rules the seller has already written.
try {
  writeFileSync('.gitignore', 'node_modules/\nbuild/\n.react-router/\n.env*\n', { flag: 'wx' });
} catch (error) {
  if (error.code !== 'EEXIST') { throw error; }
}
