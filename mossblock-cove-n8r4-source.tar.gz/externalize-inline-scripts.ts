import { createHash } from 'node:crypto';
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const SCRIPT = /<script\b([^>]*)>([\s\S]*?)<\/script\b[^>]*>/gi;
const ASYNC = /\sasync\b(?:="[^"]*")?/i;
const TYPE = /\stype=["']?([^"'\s>]*)/i;

// Data blocks such as `type="application/json"` never run, so the CSP allows them
// inline, and moving one into a `src` file would leave it empty.
function runsAsScript(attributes: string): boolean {
  const type = TYPE.exec(attributes)?.[1].toLowerCase() ?? '';
  return ['', 'module', 'text/javascript', 'application/javascript'].includes(type);
}

// Hosted apps are served with `default-src 'self'`, which blocks inline scripts.
// React Router's SPA output hydrates through inline scripts, so the app would stay
// on its loading screen. Move each one into a same-origin file, in place: the
// tags keep their order and type, so classic scripts still run before the module
// bootstrap.
//
// `async` is dropped because React hydration skips an `async` script whose `src`
// differs from what `<Scripts />` renders, and then fails with a hydration
// mismatch (React error #418). Without it the module bootstrap is deferred, which
// still runs it after the classic scripts above it.
export async function externalizeInlineScripts(clientDirectory: string, basename: string): Promise<void> {
  const assetBase = `${basename.replace(/\/?$/, '/')}assets/`;
  const pages = (await readdir(clientDirectory, { recursive: true }))
    .filter((path) => path.endsWith('.html'));

  for (const page of pages) {
    const path = join(clientDirectory, page);
    const html = await readFile(path, 'utf8');
    const scripts: Array<{ name: string; body: string }> = [];
    const rewritten = html.replace(SCRIPT, (tag, attributes: string, body: string) => {
      if (/\bsrc=/i.test(attributes) || body.trim() === '' || !runsAsScript(attributes)) {
        return tag;
      }
      const name = `inline-${createHash('sha256').update(body).digest('hex').slice(0, 16)}.js`;
      scripts.push({ name, body });
      return `<script${attributes.replace(ASYNC, '')} src="${assetBase}${name}"></script>`;
    });
    await Promise.all(scripts.map(({ name, body }) => writeFile(join(clientDirectory, 'assets', name), body)));
    await writeFile(path, rewritten);
  }
}
