import type { Config } from '@react-router/dev/config';
import { join } from 'node:path';
import { externalizeInlineScripts } from './externalize-inline-scripts';

// Use SPA output; the apps runtime doesn't run React Router SSR. Route-module splitting
// stays off: @react-router/dev can crash split client loaders on navigation.
export default {
  ssr: false,
  splitRouteModules: false,
  // Runs after the SPA shell is written, so every `react-router build` is CSP-safe.
  buildEnd: async ({ reactRouterConfig }) => {
    await externalizeInlineScripts(
      join(reactRouterConfig.buildDirectory, 'client'),
      reactRouterConfig.basename,
    );
  },
} satisfies Config;
