import type { ReactElement } from 'react';
import loadingMarkStillUrl from './loading-mark-still.svg';
import loadingMarkUrl from './loading-mark.svg';
import './loading-screen.css';

// The page an App shows until its JavaScript runs: the Squaremates loader from the
// Dashboard (managerbot-ui's TheManager2, as in the ArtifactPreviewStates story).
// It is prerendered into the static shell, so it animates with SMIL and CSS alone:
// hosted Apps' CSP blocks inline styles and scripts.
//
// The mark is an <img>, not inline SVG. Chrome doesn't start an inline SVG's
// animations until the page's load event, which waits for the JavaScript, so on a
// slow load an inline mark stays frozen on its first shape. An SVG image runs its
// own clock from when the image loads.
export function LoadingScreen(): ReactElement {
  return (
    <main className="app-loading">
      <p role="status" className="app-loading-label">Loading app…</p>
      <span className="app-loading-mark" aria-hidden="true">
        <img
          className="app-loading-moving"
          src={loadingMarkUrl}
          width="75"
          height="75"
          alt="" />
        <img
          className="app-loading-still"
          src={loadingMarkStillUrl}
          width="75"
          height="75"
          alt="" />
      </span>
    </main>
  );
}
