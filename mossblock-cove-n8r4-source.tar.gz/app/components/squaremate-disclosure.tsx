import type { ReactElement } from 'react';
// Legal-approved copy: change it only with Legal's sign-off, and update
// smoke.mjs, which checks the shell for the same text.
import copy from './squaremate-disclosure-copy.json' with { type: 'json' };
import './squaremate-disclosure.css';

/**
 * Tells sellers a business made this App with AI using Squaremates, so it can't
 * pass as Square's own product. It closes every page because it's part of the root
 * layout, and it's prerendered into the static shell, so it shows before the App's
 * JavaScript runs. Apps may restyle it to fit their theme (see the stylesheet),
 * but must keep it last, readable and with Legal's exact text.
 *
 * A `div` with role="note", not a `<footer>`: a body-level footer is a contentinfo
 * landmark, and an App with its own page footer would then have two.
 */
export function SquaremateDisclosure(): ReactElement {
  return (
    <div className="squaremate-disclosure" data-squaremate-disclosure="banner" role="note">
      <p className="squaremate-disclosure-text">{copy.appBanner}</p>
    </div>
  );
}
