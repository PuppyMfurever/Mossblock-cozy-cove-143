import {
  classifySquareRequestFailure,
  type SquareRequestFailure,
  type SquareRequestFailureKind,
} from '@square/service-apps-apollo-client/transport';
import type { ReactElement } from 'react';
import copy from './square-request-error-copy.json' with { type: 'json' };

type Action = 'retry' | 'reload' | null;

const SHOWN: Record<Exclude<SquareRequestFailureKind, 'cancelled' | 'rate_limited'>, { message: string; action: Action }> = {
  // Reloading after the seller reconnects in Chats is what clears the platform's denial.
  reconnect_required: { message: copy.reconnectRequired, action: 'reload' },
  session_changed: { message: copy.sessionChanged, action: 'reload' },
  role_denied: { message: copy.roleDenied, action: null },
  action_blocked: { message: copy.actionBlocked, action: null },
  forbidden: { message: copy.forbidden, action: null },
  bad_request: { message: copy.badRequest, action: null },
  too_large: { message: copy.tooLarge, action: null },
  timeout: { message: copy.timeout, action: 'retry' },
  endpoint_changed: { message: copy.endpointChanged, action: null },
  unavailable: { message: copy.unavailable, action: 'retry' },
};

function waitMessage(seconds: number | undefined): string {
  if (seconds === undefined) {
    return copy.rateLimited;
  }
  if (seconds === 1) {
    return copy.rateLimitedOneSecond;
  }
  if (seconds > 3600) {
    // Above an hour, minutes read as an odd number (1440 minutes); this is always 2 or more.
    return copy.rateLimitedHours.replace('{hours}', String(Math.ceil(seconds / 3600)));
  }
  return seconds > 90
    ? copy.rateLimitedMinutes.replace('{minutes}', String(Math.ceil(seconds / 60)))
    : copy.rateLimitedSeconds.replace('{seconds}', String(seconds));
}

/** What to tell the seller about a failed Square request, or null when there's nothing to say. */
export function describeSquareRequestFailure(failure: SquareRequestFailure): { message: string; action: Action } | null {
  if (failure.kind === 'cancelled') {
    return null;
  }
  if (failure.kind === 'rate_limited') {
    return { message: waitMessage(failure.retryAfterSeconds), action: 'retry' };
  }
  return SHOWN[failure.kind];
}

function retry(onRetry: () => unknown): void {
  // Called without arguments: Apollo's refetch reads its first argument as new variables.
  Promise.resolve(onRetry()).catch(() => undefined);
}

/**
 * Shows why a Square request failed. Pass the `error` from Apollo's `useQuery` or
 * `useMutation`, or an `Outcome` from `scope.transport`. Pass `onRetry` (for
 * example `refetch`) to offer Try again when waiting can help. A retry that fails
 * again rejects; the query's new error is what the seller sees, so the rejection is
 * swallowed here instead of reaching error logging. Never retry a write
 * without the seller confirming it again. On an auth change (`isAuthChange`), render
 * this instead of the query's last data, which Apollo keeps after a failed refetch.
 */
export function SquareRequestError({ error, onRetry }: { error: unknown; onRetry?: () => unknown }): ReactElement | null {
  const failure = classifySquareRequestFailure(error);
  const shown = failure && describeSquareRequestFailure(failure);
  if (!shown) {
    return null;
  }
  return (
    <div role="alert">
      <p>{shown.message}</p>
      {shown.action === 'retry' && onRetry ? <button type="button" onClick={() => retry(onRetry)}>{copy.tryAgain}</button> : null}
      {shown.action === 'reload' ? <button type="button" onClick={() => globalThis.location.reload()}>{copy.reload}</button> : null}
    </div>
  );
}
