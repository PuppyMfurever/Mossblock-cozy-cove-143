import { ApolloProvider } from '@apollo/client/react';
import {
  createBrowserTransport,
  createClientScope,
} from '@square/service-apps-apollo-client/transport';
import {
  useEffect, useState, type ReactElement, type ReactNode,
} from 'react';
import {
  Links, Meta, Outlet, Scripts, ScrollRestoration,
} from 'react-router';

import { LoadingScreen } from './components/loading-screen';
import { SquaremateDisclosure } from './components/squaremate-disclosure';

export function Layout({ children }: { children: ReactNode }): ReactElement {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Mossblock Cove — island sandbox</title>
        <Meta />
        <Links />
      </head>
      <body>
        {children}
        {/* Required on every page; see the README's "Required disclosure". */}
        <SquaremateDisclosure />
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}

export function HydrateFallback(): ReactElement {
  return <LoadingScreen />;
}

export default function App(): ReactElement {
  const [scope, setScope] = useState<ReturnType<typeof createClientScope> | null>(null);

  useEffect(() => {
    const clientScope = createClientScope(createBrowserTransport({
      route: '/_compose/server/api/square-graph',
      encode: (operation) => ({
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(operation),
      }),
    }));
    const dispose = (): void => clientScope.dispose();
    const reloadFromBackForwardCache = (event: PageTransitionEvent): void => {
      if (event.persisted) {
        window.location.reload();
      }
    };

    window.addEventListener('pagehide', dispose);
    window.addEventListener('pageshow', reloadFromBackForwardCache);
    setScope(clientScope);

    return () => {
      window.removeEventListener('pagehide', dispose);
      window.removeEventListener('pageshow', reloadFromBackForwardCache);
      dispose();
    };
  }, []);

  useEffect(() => {
    if (!scope || window.parent === window) {
      return undefined;
    }
    // A page that frames the App, such as the Square Dashboard's App preview,
    // covers it with its own loader until this says the App has painted.
    const frame = requestAnimationFrame(() => {
      window.parent.postMessage({ type: 'square-app-ready' }, '*');
    });
    return () => cancelAnimationFrame(frame);
  }, [scope]);

  if (!scope) {
    return <HydrateFallback />;
  }

  return (
    <ApolloProvider client={scope.client}>
      <Outlet />
    </ApolloProvider>
  );
}
