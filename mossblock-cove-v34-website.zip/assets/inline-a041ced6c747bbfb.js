import "/assets/manifest-ecffa863.js";
import * as route0 from "/assets/root-C6hS-qWh.js";
  
  window.__reactRouterRouteModules = {"root":route0};

import("/assets/entry.client-BM2hYgsW.js");