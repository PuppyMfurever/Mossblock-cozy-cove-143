# Revision 16 — autumn and lava

Cindercrest in the refined cozy look now combines ochre ground, copper/orange deciduous canopies, fallen leaves and glowing orange lava. Terrain, collision, settlement locations and saves are unchanged. Updated whole-island map uses matching lava/autumn colors and lists the active realm's five settlements (removed obsolete meadow labels). Other realm render palettes unchanged. Earlier cozy and fantasy renderers retained.

Typecheck, build, smoke, realm tests and finite projections passed. Actual Cindercrest scene and full 72 by 72 map captured and visually inspected. No deployment. The orange exterior represents lava under this theme, not blue ocean. Map is a schematic of saved tiles, not a full-world perspective rendering.
