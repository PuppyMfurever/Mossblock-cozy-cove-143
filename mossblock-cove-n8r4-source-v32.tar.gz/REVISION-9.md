# Revision 9 — softer rendering

Replaced flat-shaded ellipsoid meshes with smooth gradient-shaded projected ellipsoids, retaining world coordinates and depth ordering. This is a hybrid software renderer, not a new WebGL engine or full smooth-mesh pipeline. Rounded foliage, trunks, roof tiles, arch stones and steps. Continuous grass plane removes tile seams. Original characters and buildings retained. No new dependencies, assets copied from another game, or changes to save schemas.

Passed typecheck, production build, smoke, world connectivity and projection tests. Projection test approximately 26ms in the sandbox with all-grass world, not a gameplay FPS measure. Keyboard movement changed position 36,37 to 35,37 and reload restored it. Desktop and mobile screenshots inspected; browser error output empty. Visual improvement is real but not parity with a commercial game's materials, animations, custom models or environment art. Interiors and market remain 2D. No deployment attempted.
