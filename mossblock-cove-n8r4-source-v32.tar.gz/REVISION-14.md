# Revision 14 — reversible fantasy experiment

The unchanged V13 cozy renderer remains in world-3d.ts, verified identical to its attached source archive. The experimental fantasy-world.ts adds a lower perspective, taller characters with reduced head proportions, hard-banded shading, original traveling capes, cottage spires, and an original layered alpine backdrop. Mountains remain non-traversable background art. Existing animal species, clothing, nine realms, 45 destinations, home, inventory and activities remain; this is a visual experiment, not a Genshin-scale action RPG or copied assets.

Game appearance buttons select Fantasy experiment or Original cozy look. This preference uses its own browser storage key; world-save schema remains unchanged. Both looks share progress rather than keeping divergent playthroughs. The V13 source archive in this chat provides a separate full code backup.

Build, typecheck, smoke, realm unlock/connectivity checks and finite projection checks for both renderers passed. Desktop captures of both looks reviewed, mobile captured. No deployment performed.
