# Revision 11 — realms and travel

Seven main realms, one named region per realm, five named settlements per region. Cloud realm adds five settlements after all seven main realms are visited. Realm atlas provides free fast travel. Snow, coast/undersea district, forest, swamp, lava, meadow, mountain and cloud themes. All realms use variants of the same 72x72 base geography and cottage models, with connected settlement clearings; not forty individually handcrafted cities. Existing eight neighbors are shared, not unique regional NPC casts. Undersea is an aesthetic garden district, no swimming. Lava changes water appearance, not damage rules. Mountains remain decorative background. Cloud realm uses sky-garden palette, not flight.

Original meadow save preserved; switching stores per-realm tiles and position. Inventory, avatar, home, friendship and journal remain shared. New versioned realm storage saves current player resources plus realm snapshots; invalid snapshots omitted. Existing reset only resets active world state, not the atlas.

Tests: typecheck, production build, smoke, finite projections, all 40 unique settlement spawn positions traversable and connected on generated test world. Browser travel to Snowbell and Anemone hollow confirmed; Snowbell realm survived reload, undersea realm survived reload. Browser errors empty. All realm themes not individually screenshot-reviewed; cloud unlock not exercised end-to-end in browser. Final desktop/phone undersea inspected. Atlas and snow earlier captures have pre-final text/grass detail.

Unpublished; no deploy attempted. Lightweight hybrid renderer, with repeated layouts and no claim of commercial-game fidelity.
