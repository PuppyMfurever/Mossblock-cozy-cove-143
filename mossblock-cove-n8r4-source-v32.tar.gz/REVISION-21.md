# Revision 21 — coved coastline and realm pastimes

## Map
Nine smooth shoreline indentations at two scales replace the near-round silhouette, in actual terrain and the map. Region colors remain. Removed all over-map name plaques, M letters, feature numbers and footer text. Draws small mountain, cave, market, landmark and water pictograms instead. Region names and the symbol key sit beneath the map; place names are in an expandable guide. No secret realm locations exposed.

## Games
Three playable challenges per main region, 21 total. They share three compact 2D mechanics: moving-target hit/miss with five hits in ten tries; ordered five-piece workshops with wrong-order feedback; eight-piece blueprint puzzles with reversible placements. Snow has snowball target practice, snowman assembly and snow-fort construction. Coast has shell catching, sandcastle assembly and tide-pool stones. Forest has firefly lanterns, bird nests and trails. Swamp has lily-pad targets, marsh lanterns and boardwalks. Autumn/lava has leaf catching, wreaths and cooled-stone bridges. Meadow has butterflies, bouquets and pollinator gardens. Mountain has chimes, cairns and shelters.

Games are in the expanded wilderness panel, selected from the region where the explorer stands. A region-travel selector is included. These are not 3D in-world or multiplayer activities. Constructed objects remain only in the active challenge, not placed on the persistent terrain. Local win counts save in the current browser under mossblock-minigames-v21; no village coins or inventory rewards. Leaving the panel resets unfinished rounds. No secret-realm games yet; secrets remain in the saved village version.

## Verification
Typecheck, production build, smoke test and prior terrain checks passed. New check-minigames.mjs verifies 21 unique games, correct recipes, all seven blueprints, completion/wrong-placement logic, twelve target positions, shoreline radius variation and absence of map text calls. Browser playthrough verified wrong-order recovery, completed snowman, completed eight-piece fort, five successful snowball hits in seven attempts and all three win counts after reload. Desktop map and completed snowman inspected; mobile map inspected without horizontal overflow. Browser error list empty. Other realm themes share these tested mechanics; not every theme manually played end-to-end. No deployment attempted; earlier source backups preserved.

## Visual inspection
Desktop map has a quiet unlabelled silhouette with separated symbols, readable external key and seven distinguishable color areas. Mobile key wraps and map fits. Snowman drawing changes during assembly; completed preview and status are readable. Still a simple stylized prototype, not commercial-game visual fidelity.
