# Revision 15 — reference-led cozy direction

Restored cozy direction as the default, using a separate Refined cozy look. Previous cozy and Fantasy experiment remain selectable and their renderers are unchanged from V13/V14. All nine realms and save schemas retained.

Examined five user references: woodland character sheet, cottage/terrace scene, crop garden, furniture sheet, and densely planted tropical garden. Implemented closer elevated camera, flat roof shingles instead of pill-shaped roof beads, clapboard facade courses, rectangular paneled doors, polygon trunks with root flares, individually modeled leaf planes over canopy volumes, more groundcover flecks, layered flowers/tulips, leafy garden beds, and soil rows for planted crops.

This is still a simplified procedural 3D-coordinate canvas renderer. It does not reproduce the references' mesh quality, textured materials, authored environments, animation, furniture detail or lighting. No new walkable terrace, bridge, furniture set or character rigs were added. Source and images are original; no reference assets embedded.

Typecheck, build, smoke, 1504 finite refined-renderer tile projections, nine-realm/45-settlement generated-spawn connectivity and secret unlock checks passed. Desktop/mobile renders inspected. No deployment performed. The saved preference uses a new versioned key, defaulting to refined cozy on first load; world progress remains shared.
