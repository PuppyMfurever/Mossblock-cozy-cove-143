export const gardenThemes=[
{id:'snow',name:'Frostmere',x:180,y:130,color:'#c8e2e6',style:'Frostglass beds',foods:[['snowturnip','Snow turnip','#dddbe8'],['frostpea','Frost pea','#9ebd9d'],['winterleek','Winter leek','#b7cfad']]},
{id:'mountain',name:'Skyreach',x:410,y:145,color:'#9faeae',style:'Stone-terrace gardens',foods:[['buckwheat','Highland buckwheat','#c2a57d'],['mountainherb','Mountain herb','#86a58c'],['ridgeonion','Ridge onion','#c8adcf']]},
{id:'forest',name:'Elderbough',x:160,y:335,color:'#7e9c6c',style:'Woodland raised beds',foods:[['mushroom','Woodland mushroom','#bb947e'],['hazelnut','Hazelnut','#ad8557'],['wildgarlic','Wild garlic','#abc78e']]},
{id:'meadow',name:'Bloomvale',x:340,y:335,color:'#adc581',style:'Flower-bordered allotments',foods:[['corn','Sweetcorn','#e5c974'],['strawberry','Strawberry','#cd8790'],['basil','Basil','#7eae7f']]},
{id:'coast',name:'Pearlreach',x:525,y:350,color:'#a3d3ce',style:'Shell-edged gardens',foods:[['seagrape','Sea grape','#91b6aa'],['coconut','Coconut','#d4b58f'],['pineapple','Pineapple','#d7bd68']]},
{id:'swamp',name:'Lanternmire',x:200,y:525,color:'#ad9ebd',style:'Reed-framed wet gardens',foods:[['lotusroot','Lotus root','#d3b9a2'],['waterchestnut','Water chestnut','#ab8e75'],['taro','Taro','#c0afd0']]},
{id:'lava',name:'Cindercrest',x:415,y:520,color:'#ce9a70',style:'Warm basalt beds',foods:[['emberpepper','Ember pepper','#cf8062'],['sweetpotato','Sweet potato','#bb8b9b'],['cinderbean','Cinder bean','#c1ab8c']]},
{id:'cloud',name:'Aetherlight',x:1048,y:1048,color:'#cfc1e7',style:'Cloudstone planters',foods:[['cloudmelon','Cloud melon','#d5d5ed'],['starberry','Starberry','#c3a5d6'],['skyspinach','Sky spinach','#a6c6b8']]},
{id:'sanctuary',name:'Everhaven isles',x:2048,y:2048,color:'#97c7b5',style:'Lagoon fruit gardens',foods:[['mango','Mango','#e0b271'],['vanilla','Vanilla orchid','#e4d8b0'],['passionfruit','Passion fruit','#b695c3']]}
];
export const realmCrops=gardenThemes.flatMap(t=>t.foods.map(([id,name,color],i)=>({id,name,color,days:i===1?3:2,realm:t.id})));
const gardenPositions:Record<string,number[][]>={"snow":[[179,154],[221,159],[139,223],[164,90],[174,224],[252,82],[258,137],[177,189],[210,83],[248,208],[215,120],[213,214],[139,170],[156,131],[275,192]],"mountain":[[495,170],[390,78],[503,96],[446,152],[411,237],[472,226],[411,161],[309,74],[353,184],[389,208],[465,100],[371,133],[318,146],[487,138],[316,186]],"forest":[[109,315],[95,244],[225,287],[71,283],[150,344],[140,396],[219,379],[181,399],[158,250],[118,264],[155,311],[74,428],[242,248],[181,327],[232,418]],"meadow":[[359,423],[303,274],[383,396],[345,334],[337,293],[409,312],[341,244],[431,263],[304,423],[252,279],[254,247],[260,410],[329,396],[406,342],[297,370]],"coast":[[489,267],[447,416],[604,419],[522,367],[489,383],[584,396],[567,305],[457,279],[548,408],[505,408],[562,340],[510,306],[555,446],[553,271],[489,437]],"swamp":[[302,490],[118,450],[236,437],[218,606],[178,484],[196,526],[156,441],[190,580],[242,560],[209,553],[301,613],[251,476],[296,562],[156,517],[214,484]],"lava":[[434,451],[342,486],[456,495],[426,494],[487,537],[389,437],[355,574],[477,456],[422,609],[327,609],[401,471],[336,536],[311,558],[440,564],[501,501]],"cloud":[[1070,1042],[1039,1022],[1069,1070],[1018,1044],[1056,1028],[1057,1072],[1024,1020],[1036,1080],[1032,1039],[1058,1058],[1021,1062],[1038,1068],[1054,1048],[1041,1034],[1073,1054]],"sanctuary":[[2028,2062],[2047,2025],[2055,2049],[2027,2022],[2033,2035],[2080,2053],[2069,2038],[2044,2053],[2051,2077],[2064,2025],[2045,2040],[2044,2068],[2064,2065],[2035,2046],[2070,2017]]};
export const gardens=gardenThemes.flatMap(t=>Array.from({length:15},(_,i)=>({id:`garden-${t.id}-${i}`,realm:t.id,region:t.name,name:`${t.style} ${i+1}`,color:t.color,x:gardenPositions[t.id][i][0],y:gardenPositions[t.id][i][1],foods:t.foods.map(f=>f[0])})));
export const realmRecipes=gardenThemes.flatMap(t=>{const [a,b,c]=t.foods.map(f=>f[0]);return [{id:`${t.id}-harvest`,name:`${t.name} harvest bowl`,ingredients:{[a]:2,[c]:1,rice:1},joy:18,description:`A comforting bowl of ${t.foods[0][1].toLowerCase()} and ${t.foods[2][1].toLowerCase()} over rice.`},{id:`${t.id}-special`,name:`${t.name} garden medley`,ingredients:{[a]:1,[b]:2,[c]:1},joy:22,description:`A local medley featuring all three crops from ${t.name}.`}];});

export const extraRecipes=gardenThemes.flatMap(t=>{const [a,b,c]=t.foods.map(f=>f[0]);const [an,bn,cn]=t.foods.map(f=>f[1]);return [
{id:t.id+'-soup',name:an+' soup',ingredients:{[a]:2,potato:1}},
{id:t.id+'-mash',name:bn+' mash',ingredients:{[b]:2,potato:2}},
{id:t.id+'-rice',name:cn+' rice pot',ingredients:{[c]:2,rice:2}},
{id:t.id+'-stew',name:t.name+' tomato stew',ingredients:{[a]:1,[b]:1,tomato:2}},
{id:t.id+'-salad',name:t.name+' chopped salad',ingredients:{[a]:1,[c]:2,carrot:1}},
{id:t.id+'-roast',name:t.name+' tray roast',ingredients:{[b]:2,[c]:1,pumpkin:1}},
{id:t.id+'-pilaf',name:t.name+' garden pilaf',ingredients:{[a]:1,[b]:1,[c]:1,rice:2}},
{id:t.id+'-hotpot',name:t.name+' harvest hotpot',ingredients:{[a]:2,[b]:1,[c]:1,potato:1}}
].map((r,i)=>({...r,joy:12+i*2,description:`A ${t.name} recipe using the listed garden ingredients.`}));});
export const pantryRecipes=[
{id:'carrot-mash',name:'Carrot and potato mash',ingredients:{carrot:2,potato:2}},
{id:'tomato-rice',name:'Tomato rice pot',ingredients:{tomato:2,rice:2}},
{id:'pumpkin-soup',name:'Pumpkin soup',ingredients:{pumpkin:2,potato:1}},
{id:'berry-rice',name:'Berry rice pudding',ingredients:{berry:2,rice:1}},
{id:'garden-stew',name:'Four-crop garden stew',ingredients:{carrot:1,potato:1,tomato:1,pumpkin:1}},
{id:'pumpkin-rice',name:'Golden pumpkin rice',ingredients:{pumpkin:1,rice:2,carrot:1}}
].map(r=>({...r,joy:16,description:'A simple pantry meal made from your harvested crops.'}));
