// Original decorative distant scenery. These mountains are not playable terrain.
export function paintFantasyHorizon(ctx:CanvasRenderingContext2D,px:number,py:number){
const W=1100,H=660;const horizon=119;const sky=ctx.createLinearGradient(0,0,0,300);sky.addColorStop(0,'#64b7e5');sky.addColorStop(.65,'#aadbe6');sky.addColorStop(1,'#d9ecda');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
const path=(points:number[][],fill:string)=>{ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();};
const shift=(px-36)*1.7;const distant=(px-36)*.65;
// Layered silhouettes, with a split in the center framing the village.
path([[-170-distant,horizon],[45-distant,58],[95-distant,66],[175-distant,8],[228-distant,25],[287-distant,83],[370-distant,48],[458-distant,96],[550-distant,111],[685-distant,79],[757-distant,25],[798-distant,46],[889-distant,-9],[942-distant,27],[1050-distant,70],[1260-distant,14],[1280,horizon+32],[-170,horizon+32]],'#8bb7cc');
path([[95-distant,66],[175-distant,8],[228-distant,25],[203-distant,65],[181-distant,57],[158-distant,73]],'#cce3e8');
path([[798-distant,46],[889-distant,-9],[942-distant,27],[912-distant,39],[884-distant,22],[861-distant,53]],'#d8e9eb');
path([[-170-shift,horizon+20],[-60-shift,35],[16-shift,59],[66-shift,26],[110-shift,43],[140-shift,99],[197-shift,67],[230-shift,102],[280-shift,93],[323-shift,124],[510-shift,145],[614-shift,126],[706-shift,118],[758-shift,84],[796-shift,90],[831-shift,39],[864-shift,34],[910-shift,93],[940-shift,61],[1000-shift,101],[1080-shift,42],[1200-shift,89],[1270,165],[-170,165]],'#729eac');
// Sculpted rock faces and illuminated grassy caps.
for(const [x,y,w,h] of [[-30,72,170,110],[102,99,110,71],[770,93,113,80],[946,79,148,118]]){const xx=x-shift;path([[xx-w*.5,y+h],[xx-w*.44,y+17],[xx-w*.28,y],[xx+w*.34,y+7],[xx+w*.48,y+h]],'#73998e');path([[xx-w*.28,y],[xx+w*.34,y+7],[xx+w*.48,y+h],[xx+w*.07,y+h],[xx+w*.15,y+32]],'#8bad9b');path([[xx-w*.44,y+17],[xx-w*.28,y-3],[xx+w*.34,y+3],[xx+w*.38,y+17],[xx,y+12]],'#9cbe89');path([[xx-w*.12,y+28],[xx-w*.05,y+52],[xx-w*.16,y+91]],'#5f8c88');}
// Hazy, gentle foothills connect the distant landscape to the playable plain.
ctx.beginPath();ctx.moveTo(-20,190);ctx.lineTo(-20,146);ctx.bezierCurveTo(110,101,201,136,292,143);ctx.bezierCurveTo(420,111,485,153,590,147);ctx.bezierCurveTo(731,124,817,113,940,145);ctx.bezierCurveTo(1024,112,1098,122,1140,130);ctx.lineTo(1140,210);ctx.closePath();ctx.fillStyle='#a8c89b';ctx.fill();
// Long drifting cloud forms, intentionally quiet above the mountain silhouettes.
ctx.fillStyle='#eff8f0';for(const [x,y,w] of [[335,34,83],[624,59,65],[1026,24,73]]){ctx.beginPath();ctx.ellipse(x-distant,y,w,8,0,0,Math.PI*2);ctx.ellipse(x-distant-15,y-6,w*.48,11,0,0,Math.PI*2);ctx.fill();}
}
