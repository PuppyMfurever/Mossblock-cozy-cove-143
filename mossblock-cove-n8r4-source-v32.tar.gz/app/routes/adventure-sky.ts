// Original illustrated fantasy backdrop. Decorative only, not traversable geometry.
export function paintAdventureSky(ctx:CanvasRenderingContext2D,px:number){
const sky=ctx.createLinearGradient(0,0,0,225);sky.addColorStop(0,'#328ac2');sky.addColorStop(.6,'#91cddd');sky.addColorStop(1,'#d5e4b9');ctx.fillStyle=sky;ctx.fillRect(0,0,1100,220);
const ridge=(pts:number[][],color:string)=>{ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fillStyle=color;ctx.fill();};const shift=(px-36)*1.5;
for(const [x,y,w,h] of [[50,26,190,175],[290,64,150,133],[940,8,210,200],[715,71,130,125]]){const cx=x-shift;ridge([[cx-w,210],[cx-w*.45,y+h*.35],[cx,y],[cx+w*.2,y+h*.42],[cx+w,210]],'#80adbe');ridge([[cx,y],[cx+w*.2,y+h*.42],[cx+w,210],[cx+w*.1,210]],'#6f9cad');ridge([[cx-w*.14,y+h*.15],[cx,y],[cx+w*.11,y+h*.23],[cx+w*.04,y+h*.19],[cx-w*.06,y+h*.22]],'#e1f0e7');}
for(const [x,y,w] of [[120,141,120],[845,150,140]]){const cx=x-shift;ridge([[cx-w,222],[cx-w*.8,y],[cx-w*.2,y-12],[cx+w*.55,y+10],[cx+w,222]],'#5f8d84');ridge([[cx-w*.8,y],[cx-w*.2,y-12],[cx+w*.55,y+10],[cx+w*.5,y+20],[cx-w*.75,y+12]],'#a2be71');ctx.strokeStyle='#d2e7c4';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(cx+22,y+14);ctx.bezierCurveTo(cx+12,y+45,cx+31,199,cx+15,220);ctx.stroke();}
ctx.fillStyle='#eff6e7';for(const [x,y,w] of [[430,29,66],[635,60,47],[1020,49,66]]){ctx.beginPath();ctx.ellipse(x-shift*.3,y,w,6,0,0,7);ctx.ellipse(x-shift*.3-15,y-7,w*.5,11,0,0,7);ctx.fill();}
const glow=ctx.createRadialGradient(725,31,3,725,31,75);glow.addColorStop(0,'#fff6d680');glow.addColorStop(1,'#fff6d600');ctx.fillStyle=glow;ctx.fillRect(650,0,150,106);
}
