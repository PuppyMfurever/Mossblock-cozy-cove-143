# Large-world revision

The map is now 72 by 72 (5,184 total tiles including water), replacing the 18 by 18 map: 16 times the map area. The camera follows the player. Five named regions, eight original animal neighbors, a whole-island map, and return-home control. Gardening progresses from planted seed to ripe crop when resting. Harvest gives four berries and one seed. Neighbor gifts consume a berry. Trading gives three coins per berry and eight per fish; seeds cost four coins. Coins are fictional game currency, not money. New craft: picnic bench. Save uses a separate v2 browser storage key so v1 data remains untouched; no cloud saving.

Local verification: typecheck, production build, and smoke test passed. Tested gather, movement, seed planting, day advance, harvest, neighbor gift, produce sale, map open, and save/reload. Connectivity test found 3,136 walkable tiles and routes within interaction distance of all eight neighbors, plus reachable fishing water. Fishing logic implemented but not manually played end-to-end. Desktop, mobile, map, and dark-preference disclosure screenshots inspected. No new merchant data use or Square business writes.

Publishing state at preparation: original small-world publish remains pending; no deployed version or URL confirmed. Do not deploy the revision until that earlier request is dismissed or resolved and current state is checked. Do not approve the earlier small-world artifact to publish this revision; it contains different files.

Source path in this sandbox: /tmp/mossblock-cove. Registered app ID: app_mossblock-cove-n8r4. This archive contains editable source, not a confirmation of deployment.
