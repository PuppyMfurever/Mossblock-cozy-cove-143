import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
let source=fs.readFileSync('app/routes/home.tsx','utf8');
source=source.slice(source.indexOf('type Tile='),source.indexOf('function valid('));
const code=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
const {world,people,size}=new Function(code+';return {world:initial(),people:neighbors,size:N};')();
assert.equal(world.tiles.length,5184); assert.equal(people.length,8);
let seen=new Set([world.y*size+world.x]),queue=[world.y*size+world.x];let waterReachable=false;
for(let q=0;q<queue.length;q++){const i=queue[q],x=i%size,y=Math.floor(i/size);for(const [dx,dy]of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,j=ny*size+nx;if(nx<0||ny<0||nx>=size||ny>=size)continue;if(world.tiles[j]==='water')waterReachable=true;if(seen.has(j)||['water','house','tree','rock','lantern','bench'].includes(world.tiles[j]))continue;seen.add(j);queue.push(j);}}
for(const n of people)assert(queue.some(i=>Math.abs(i%size-n.x)+Math.abs(Math.floor(i/size)-n.y)<=2),n.name+' unreachable');
assert(waterReachable);assert(queue.length>2500);console.log(JSON.stringify({tiles:world.tiles.length,reachableTiles:queue.length,neighbors:people.length,allNeighborsReachable:true,fishingWaterReachable:waterReachable}));
