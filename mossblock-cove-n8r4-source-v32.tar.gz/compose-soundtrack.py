from pathlib import Path
import math,wave,array,json
out=Path(__file__).parent/'public'/'music';out.mkdir(parents=True,exist_ok=True)
sr=22050
tracks=[('meadow','Morning in Bloomvale',60,92),('snow','Lanterns in the Snow',62,72),('forest','Under the Elderbough',57,84),('coast','Pearlreach Tide',65,88),('swamp','Fireflies at Dusk',55,76),('lava','Emberleaf Waltz',60,96),('mountain','Highwind Reverie',62,80),('cloud','Aetherlight Lullaby',67,68),('sanctuary','Everhaven Homecoming',65,82)]
for ix,(realm,title,root,bpm) in enumerate(tracks):
 beat=60/bpm;duration=32*beat;n=int(duration*sr);mix=[0.0]*n
 def note(midi,start,length,amp,voice=0):
  freq=440*2**((midi-69)/12);start=int(start*sr);length=int(length*sr)
  for j in range(min(length,n-start)):
   t=j/sr;env=min(1,t/.025)*min(1,(length-j)/(sr*.12))*math.exp(-t*(2.2 if voice==0 else .6));signal=math.sin(2*math.pi*freq*t)+.22*math.sin(2*math.pi*freq*2*t)+.08*math.sin(2*math.pi*freq*3*t)
   mix[start+j]+=signal*amp*env
 progression=[0,5,9,7];motifs=[[0,4,7,12,9,7,4,2],[7,12,14,12,7,4,2,0],[0,2,4,7,4,2,0,7],[4,7,9,12,14,12,9,7]]
 for bar in range(8):
  offset=progression[bar%4]
  for j in range(4):
   degree=[0,7,12,7][j];note(root-12+offset+degree,(bar*4+j)*beat,beat*1.5,.055,1)
  motif=motifs[(bar+ix)%4]
  for j in range(4):
   midi=root+motif[(j*2+bar)%8]+(12 if realm in ['cloud','snow'] else 0)
   note(midi,(bar*4+j+.0)*beat,beat*.85,.10)
 peak=max(abs(x) for x in mix) or 1
 samples=array.array('h',(int(max(-1,min(1,x/peak*.55))*32767) for x in mix))
 with wave.open(str(out/(realm+'.wav')),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(sr);f.writeframes(samples.tobytes())
 print(realm,title,round(duration,2),'seconds')
(out/'tracklist.json').write_text(json.dumps([{'realm':r,'title':t,'bpm':b} for r,t,_,b in tracks],indent=2))
