# Revision 20 — mapped terrain features and markets

Expanded wilderness now has six named mountain masses, five lakes, eight ponds, six cave entrances, four named hill areas and three river routes. Natural features are numbered on the map with a matching list and visit selector. Lakes remain water even in autumn/lava region; lava stream remains impassable. Caves are visible entrances only, not underground rooms.

Added 21 marketplace locations, three for each main region, with three-stall original drawings, map M markers, and visit selector. These are scenic destinations, not functional new trading shops. Existing functional market remains in the saved village version. No secret locations exposed.

House image shows actual unchanged saved-village cottages; these houses are not yet integrated into expanded wilderness. Updated source is local/unpublished. Typecheck/build/smoke, terrain tests, count tests passed. Current house, market and complete map screenshots inspected. 32 numbered natural features and 21 market coordinates exported as map key CSV.
