# Revision 19 — landmarks and resident life

Added seven large original landmark illustrations anchored in the terrain: Sunbell residence hall, Frostglass spire, Highwind observatory, Elderheart tree, Pearlwatch lighthouse, Moonreed arch, Emberleaf clocktower. A landmark selector moves the explorer to each site. Small ground clearings keep them out of water. Map marks their coordinates. Landmarks are rendered 2D illustrations on the terrain, not enterable buildings or collision meshes.

Added separate resident-life panel: four original starter residents, four personality labels, hunger/joy/player-friendship values, meals, spending time, simulated next-day needs and short pair event text. Up to 12 residents can be named/added. Separate browser persistence; no link to original village friendship system. No autonomous NPC movement, resident-to-resident relationship simulation, romance, interiors or voices. No copied game characters/assets.

Typecheck, build, smoke and terrain checks passed. Browser verified meal changes and persistence after reload. Landmark hall and resident panel inspected. Other landmark drawings implemented but not individually visually inspected. Still unpublished, previous source backups retained.
