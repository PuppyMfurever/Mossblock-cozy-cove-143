import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
const code=ts.transpileModule(fs.readFileSync('app/routes/landscape.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const ex={};new Function('exports',code)(ex);
const grad={addColorStop(){}};
const ctx=new Proxy({canvas:{},createLinearGradient:()=>grad,createRadialGradient:()=>grad},{get(o,k){return k in o?o[k]:()=>{}},set(o,k,v){o[k]=v;return true;}});
const tiles=Array(72*72).fill('grass');const hits=ex.renderLandscape(ctx,tiles,72,36,36,0,[],{name:'Test',kind:'human',tone:'#d6a77e',hair:'#30251f',style:'short',outfit:'#507b77'},false,()=>{},'Test');
for(const y of [30,34,36,38,39]){const hit=hits.find(h=>h.index===y*72+36);assert(hit);const cx=hit.points.reduce((s,p)=>s+p[0],0)/4,cy=hit.points.reduce((s,p)=>s+p[1],0)/4;assert.equal(ex.pickGround(hits,cx,cy),hit.index);}
assert.equal(ex.pickGround(hits,550,50),null);console.log('Perspective tile selection passed at five depths; sky is not selectable.');
