# Revision 8 — first 3D village renderer

The exterior now uses actual three-dimensional mesh coordinates, perspective projection, per-face lighting, depth sorting, distance haze and ground shadows, rasterized locally through Canvas 2D. It is not WebGL, not a screenshot or a pre-rendered illustration. Rounded mesh characters, trees and foliage, dimensional cottages with tiled pitched roofs, stone arch surrounds, lanterns and windows. The camera tracks player position.

Existing world and avatar save formats retained. 72x72 world, gathering, inventory, NPC interactions and other state logic unchanged. Existing interior, market and avatar-preview panels are still 2D; this is the first exterior 3D pass, not full-game visual parity. Clothing/accessories translated to simple mesh details; hairstyles and accessories remain approximate. No copyrighted assets or game code used. No external dependencies added.

Checks passed: TypeScript, production build, starter smoke, world connectivity, 1504 finite ground projections in the software-render test. Keyboard left changed position 37,37 to 36,37; reload preserved 36,37. Desktop 1280x900 and mobile 390x844 inspected; browser errors empty. Initial render was revised to lower camera and soften lighting. Remaining: visible faceting, fixed front-facing characters, coarse animation, furniture-panel 3D conversion, and testing every interaction in the new projection. Render test with all-grass world approximately 127ms in this sandbox before browser display; no high-frame-rate claim.

Unpublished. No deployment attempted. Source snapshot preserves editability. Existing registered app and prior approval state unchanged.
