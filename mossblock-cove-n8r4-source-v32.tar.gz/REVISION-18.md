# Revision 18 — continuous terrain prototype

Added optional Expanded wilderness: a procedural 680x680 continuous height-field, seven Voronoi color regions, irregular coastline, continuous river, lake and ponds. Walking follows height; blue water allows swimming; inland lava blocks entry. Rendered locally around player, no sector loading on regional borders. 462400 cells versus prior 46656 bounding cells: 9.91x. Not 9.91x land area; prior land/sector arrangement differs.

Explicit limitation: separate terrain exploration mode, not a migration of the village gameplay. Existing 35 settlements, NPC quests, homes, customized avatar and hidden realm discovery are not integrated into wilderness. Those remain playable in Return to saved village. Wilderness position alone is saved separately. No original progress deleted. Visuals remain simplified procedural prototype, no climbing animation, camera rotation or physics swimming.

Build/typecheck/smoke, terrain heights, water entry and finite sample checks passed. Browser swimming movement tested and map captured. No deployment.
