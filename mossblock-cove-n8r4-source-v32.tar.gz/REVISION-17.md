# Revision 17 — connected island and hidden discoveries

Seven 72x72 sectors arranged within a 216x216 bounding grid. Reciprocal cardinal paths allow edge-to-edge travel, loading adjacent sectors. The full map labels/color-codes all seven. This is sector-based traversal, not one simultaneously rendered mesh. Existing regional terrain persists, with central crossing paths cleared on migration/travel; earlier source backups retained.

Secrets now require explicit discovery, not visited flags. Cloud: day 10+, four friends, two completed requests, all seven regions visited, interaction at remote mountain landmark. Sanctuary: cloud unlocked, day 20+, four completed requests, five discovery types, interaction at remote coastal landmark. In-game days are advanced by resting, not real-world days. New explicit secret unlock save key; old visited flags do not grant access. Locations/thresholds intentionally not shown to the player. Main atlas has only seven entries until unlocks. Automated gate and reciprocal path checks passed; full end-to-end secret quest completion not manually played.

Typecheck/build/smoke, nine-region settlement test, finite projection tests passed. Browser map and hidden atlas entries checked. No deployment.
