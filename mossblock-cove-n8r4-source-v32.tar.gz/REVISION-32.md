# Revision 32 — scattered gardens and 100 recipes

Expanded the 22-recipe cookbook to 100 ingredient-consuming recipes: 10 per realm and 10 shared pantry recipes. Added name search. Secret-realm recipes remain gated. Relocated the same 135 gardens (15 per realm), preserving garden IDs, planted crops and shared pantry state. Main-realm garden centers are at least 29 tiles apart; compact secret-realm centers are at least 10 tiles apart. All centers validated as dry terrain in the intended region. Existing six-bed garden is unchanged.

Verified: TypeScript, production build, smoke checks, garden/save validation, ingredient consumption for all recipes and nine-realm mesh checks. Browser inspected recipe search and retained pantry. This is a local unpublished prototype; existing publication blocker remains unchanged. Visual panels and cooking are still 2D, garden props are 3D. No claim of full-game completion or online multiplayer.
